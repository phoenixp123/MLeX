import os

from Lab6.MLeX.trial import Trial

class Experiment:
    def __init__(self, id):
        self.id = id
        self.trials = []

    def add_trial(self,trial):
        self.trials.append(trial)

    # TODO: Summarize trials results
    def get_trials(self, print_trials=False):
        if print_trials:
            for trial in self.trials: print(trial)

        return self.trials

    # TODO: Support rapid search for best trial results
    def get_trial_by_id(self,trial_id):
        for trial in self.trials:
            if trial.id == trial_id:
                return trial
        return None

    def save_trials(self):
        current_directory = f"experiment-{self.id}-trials"
        try:
            os.makedirs(current_directory, exist_ok = True)
        except:
            print(f"An error occurred while trying to save experiment: {self.id} in {current_directory}")

        for trial in self.trials:
            trial.save(path =current_directory + "/" + str(trial.trial))

    def __str__(self):
        return "Experiment(name={})".format(self.id)

if __name__ == "__main__":
    my_experiment = Experiment(id=0)
    trial_0 = Trial(trial=0, experiment=0)
    trial_1 = Trial(trial=1, experiment=0)
    trial_2 = Trial(trial=2, experiment = 0)

    my_experiment.add_trial(trial_0)
    my_experiment.add_trial(trial_1)
    my_experiment.add_trial(trial_2)
    my_experiment.save_trials()
    my_experiment.get_trials()
